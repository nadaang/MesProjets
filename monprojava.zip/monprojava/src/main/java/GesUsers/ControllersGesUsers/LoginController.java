package GesUsers.ControllersGesUsers;

import GesUsers.entities.Enfant;
import GesUsers.entities.User;
import GesUsers.services.CaptchaService;
import GesUsers.services.EnfantService;
import GesUsers.services.UserService;
import GesUsers.tools.UserSession;
import com.sun.net.httpserver.HttpServer;
import javafx.application.Platform;
import javafx.concurrent.Worker;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import javafx.stage.Stage;
import netscape.javascript.JSObject;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.URI;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class LoginController {
    @FXML private TabPane userTabPane;
    @FXML private Tab parentTab;
    @FXML private Tab enfantTab;
    @FXML private TextField emailField;
    @FXML private PasswordField passwrdField;
    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;
    @FXML private Button loginButton;
    @FXML private Hyperlink signupLink;



/*------------------------------------------------------------------------------------------*/


    @FXML private HBox emojiCaptchaContainer;
    @FXML private StackPane recaptchaContainer;
    @FXML private WebView captchaWebView;


    private final String[] EMOJIS = {"🐶", "🐱", "🐭", "🐹", "🐰", "🦊", "🐻", "🐼"};
    private String expectedEmoji;
    private int failedAttempts = 0;
    private final CaptchaService captchaService = new CaptchaService();

    private UserService userService = new UserService();
    private EnfantService enfantService = new EnfantService();
    @FXML
    private void initialize() {
        // Gestionnaire d'événement pour le bouton de connexion
        loginButton.setOnAction(event -> handleLogin());

        // Gestionnaire pour le lien d'inscription
        signupLink.setOnAction(event -> {
            try {
                loadSignupPage();
            } catch (IOException e) {
                e.printStackTrace();
            }
        });

        // Désactiver le champ code initialement
        passwordField.setDisable(true);

        // Écouteur sur le champ username
        usernameField.textProperty().addListener((obs, oldVal, newVal) -> {
            if (!newVal.isEmpty() && userTabPane.getSelectionModel().getSelectedItem() == enfantTab) {
                setupEmojiCaptcha(newVal);
            }
        });

    }

    private void setupEmojiCaptcha(String username) {
        // Calculer l'emoji attendu
        int hash = username.hashCode();
        expectedEmoji = EMOJIS[Math.abs(hash % EMOJIS.length)];

        // Générer 3 mauvaises options + la bonne
        List<String> options = new ArrayList<>(Arrays.asList(EMOJIS));
        options.remove(expectedEmoji);
        Collections.shuffle(options);
        options = options.subList(0, 3);
        options.add(expectedEmoji);
        Collections.shuffle(options);

        // Afficher les boutons emoji
        emojiCaptchaContainer.getChildren().clear();
        options.forEach(emoji -> {
            Button btn = new Button(emoji);
            btn.setStyle("-fx-font-size: 24px; -fx-background-color: transparent;");
            btn.setOnAction(e -> validateEmojiSelection(emoji));
            emojiCaptchaContainer.getChildren().add(btn);
        });

        // Cacher reCAPTCHA initialement
        recaptchaContainer.setVisible(false);
    }

    private void validateEmojiSelection(String selectedEmoji) {
        if (selectedEmoji.equals(expectedEmoji)) {
            passwordField.setDisable(false);
            failedAttempts = 0; // Réinitialiser le compteur
        } else {
            failedAttempts++;
            if (failedAttempts >= 3) {
                activateRecaptcha();
            } else {
                showAlert("Erreur", "Mauvaise icône! Tentatives restantes: " + (3 - failedAttempts), Alert.AlertType.ERROR);
            }
        }
    }

  /*  private void activateRecaptcha() {
        emojiCaptchaContainer.setVisible(false);
        recaptchaContainer.setVisible(true);

        // Utilisez votre nouvelle clé de site ici
        String htmlContent = """
        <html>
          <head>
            <script src="https://www.google.com/recaptcha/api.js" async defer></script>
            <script>
              function onCaptchaSuccess(token) {
                javaConnector.onCaptchaSuccess(token);
              }
            </script>
          </head>
          <body>
            <div class="g-recaptcha" 
                 data-sitekey="VOTRE_NOUVELLE_CLE_SITE" 
                 data-callback="onCaptchaSuccess">
            </div>
          </body>
        </html>
    """;

        captchaWebView.getEngine().loadContent(htmlContent);
        JSObject window = (JSObject) captchaWebView.getEngine().executeScript("window");
        window.setMember("javaConnector", new JavaConnector());
    }*/


    private void activateRecaptcha() {
        emojiCaptchaContainer.setVisible(false);
        recaptchaContainer.setVisible(true);


        startLocalServer();
        captchaWebView.getEngine().load("http://localhost:8081/recaptcha.html");

        // Attendre que la page soit chargée
        captchaWebView.getEngine().getLoadWorker().stateProperty().addListener((obs, oldState, newState) -> {
            if (newState == Worker.State.SUCCEEDED) {
                JSObject window = (JSObject) captchaWebView.getEngine().executeScript("window");
                window.setMember("javaConnector", new JavaConnector());
            }
        });
    }



    // Ajoutez cette méthode
    private void startLocalServer() {
        new Thread(() -> {
            try {
                HttpServer server = HttpServer.create(new InetSocketAddress(8081), 0); // Changé à 8081
                server.createContext("/recaptcha.html", exchange -> {
                    String htmlContent = """
                <!DOCTYPE html>
                <html>
                <head>
                    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
                    <script>
                        function onCaptchaSuccess(token) {
                            if (window.javaConnector) {
                                javaConnector.onCaptchaSuccess(token);
                            }
                        }
                    </script>
                </head>
                <body>
                    <div class="g-recaptcha"
                         data-sitekey="6Lc7AiIrAAAAAME88VHKZvVdjR4t85PLC0oeTpEl"
                         data-callback="onCaptchaSuccess">
                    </div>
                </body>
                </html>
                """;
                    exchange.getResponseHeaders().set("Content-Type", "text/html");
                    exchange.sendResponseHeaders(200, htmlContent.getBytes().length);
                    try (OutputStream os = exchange.getResponseBody()) {
                        os.write(htmlContent.getBytes());
                    }
                });
                server.setExecutor(null);
                server.start();
                System.out.println("Serveur démarré sur le port 8081");
            } catch (IOException e) {
                System.err.println("Erreur du serveur: " + e.getMessage());
                e.printStackTrace();
            }
        }).start();
    }

    public class JavaConnector {
        public void onCaptchaSuccess(String token) {
            Platform.runLater(() -> {
                System.out.println("reCAPTCHA validé! Token: " + token); // Debug
                passwordField.setDisable(false); // Débloquer le champ
                recaptchaContainer.setVisible(false); // Cacher reCAPTCHA
            });
        }
    }





    private void handleLogin() {
        if (userTabPane.getSelectionModel().getSelectedItem() == parentTab) {
            // Authentification Parent/User
            authenticateUser();
        } else {
            // Authentification Enfant
            authenticateEnfant();
        }
    }

    private void authenticateUser() {
        String email = emailField.getText().trim();
        String password = passwrdField.getText().trim();

        if (email.isEmpty() || password.isEmpty()) {
            showAlert("Erreur", "Veuillez remplir tous les champs", Alert.AlertType.ERROR);
            return;
        }

        try {
            User user = userService.authenticate(email, password);
            if (user != null) {
                // Démarrer la session
                UserSession.getInstance().startUserSession(user);
                redirectBasedOnRole(user.getRole());
            } else {
                showAlert("Erreur", "Email ou mot de passe incorrect", Alert.AlertType.ERROR);
            }
        } catch (Exception e) {
            showAlert("Erreur", "Une erreur est survenue: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    private void authenticateEnfant() {
        String username = usernameField.getText().trim();
        String code = passwordField.getText().trim();

        if (username.isEmpty() || code.isEmpty()) {
            showAlert("Erreur", "Veuillez remplir tous les champs", Alert.AlertType.ERROR);
            return;
        }

        try {
            Enfant enfant = enfantService.authenticate(username, code);
            if (enfant != null) {
                // Démarrer la session
                UserSession.getInstance().startEnfantSession(enfant);
                redirectToEnfantPage(enfant);
            } else {
                showAlert("Erreur", "Nom d'utilisateur ou code incorrect", Alert.AlertType.ERROR);
            }
        } catch (Exception e) {
            showAlert("Erreur", "Une erreur est survenue: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    private void redirectBasedOnRole(String role) throws IOException {
        String fxmlFile;
        switch (role.toLowerCase()) {
            case "parent":
                fxmlFile = "/GesEnfParent.fxml";
                break;
            case "medecin":
                fxmlFile = "/MedecinDashboard.fxml";
                break;
            case "admin":
                fxmlFile = "/GesUsersAdmin.fxml";
                break;
            default:
                throw new IOException("Rôle non reconnu: " + role);
        }

        loadFXMLFile(fxmlFile);
    }

    private void redirectToEnfantPage(Enfant enfant) throws IOException {
        // Vous pouvez passer les données de l'enfant à la page suivante si nécessaire
        //loadFXMLFile("/EnfantDashboard.fxml");
        loadFXMLFile("/signup.fxml");
    }

    private void loadSignupPage() throws IOException {
        loadFXMLFile("/signup.fxml");
    }

    private void loadFXMLFile(String fxmlFile) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource(fxmlFile));
        Stage stage = (Stage) loginButton.getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }

    private void showAlert(String title, String message, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}




/*
package GesUsers.ControllersGesUsers;

import GesUsers.entities.Enfant;
import GesUsers.entities.User;
import GesUsers.entities.VoiceItChildProfile;
import GesUsers.services.*;
import GesUsers.tools.UserSession;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;

public class LoginController {
    @FXML private TabPane userTabPane;
    @FXML private Tab parentTab;
    @FXML private Tab enfantTab;
    @FXML private TextField emailField;
    @FXML private PasswordField passwrdField;
    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;
    @FXML private Button loginButton;
    @FXML private Hyperlink signupLink;
    @FXML private Button enrollVoiceButton;
    @FXML private Button voiceLoginButton;
    @FXML private Label voiceStatusLabel;

    private final UserService userService = new UserService();
    private final EnfantService enfantService = new EnfantService();
    private final MicrophoneCapture microphoneCapture = new MicrophoneCapture();
    private final HuggingFaceService huggingFaceService = new HuggingFaceService();
    //private final VoiceAuthService voiceAuthService = new VoiceAuthService();

    @FXML
    private void initialize() {
        // Initial state
        updateVoiceButtonsState(false);

        // Existing handlers
        loginButton.setOnAction(event -> handleLogin());
        signupLink.setOnAction(event -> {
            try {
                loadSignupPage();
            } catch (IOException e) {
                showError("Erreur de navigation", e.getMessage());
            }
        });

        // Voice authentication handlers
        enrollVoiceButton.setOnAction(event -> handleVoiceEnrollment());
        voiceLoginButton.setOnAction(event -> handleVoiceLogin());

        // Update buttons when username changes
        usernameField.textProperty().addListener((obs, oldVal, newVal) -> {
            if (!newVal.isEmpty() && userTabPane.getSelectionModel().getSelectedItem() == enfantTab) {
                checkVoiceEnrollmentStatus();
            }
        });

        // Update buttons when tab changes
        userTabPane.getSelectionModel().selectedItemProperty().addListener((obs, oldTab, newTab) -> {
            boolean isChildTab = newTab == enfantTab;
            enrollVoiceButton.setVisible(isChildTab);
            voiceLoginButton.setVisible(isChildTab);
            voiceStatusLabel.setVisible(isChildTab);

            if (isChildTab && !usernameField.getText().isEmpty()) {
                checkVoiceEnrollmentStatus();
            }
        });
    }

    private void checkVoiceEnrollmentStatus() {
        String username = usernameField.getText().trim();
        if (!username.isEmpty()) {
            try {
                Enfant enfant = enfantService.findByUsername(username);
                if (enfant != null) {
                    VoiceItChildProfile voiceProfile = voiceAuthService.findByChildId(enfant.getId());
                    updateVoiceButtonsState(voiceProfile != null);
                }
            } catch (Exception e) {
                // Silent error handling
            }
        }
    }

    private void updateVoiceButtonsState(boolean hasVoiceEnrollment) {
        Platform.runLater(() -> {
            voiceLoginButton.setDisable(!hasVoiceEnrollment);
            enrollVoiceButton.setDisable(hasVoiceEnrollment);

            if (hasVoiceEnrollment) {
                voiceLoginButton.setStyle("-fx-background-color: #2196F3; -fx-text-fill: white;");
                enrollVoiceButton.setStyle("-fx-background-color: #cccccc; -fx-text-fill: #666666;");
            } else {
                enrollVoiceButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white;");
                voiceLoginButton.setStyle("-fx-background-color: #cccccc; -fx-text-fill: #666666;");
            }
        });
    }

    private void handleLogin() {
        if (userTabPane.getSelectionModel().getSelectedItem() == parentTab) {
            authenticateUser();
        } else {
            authenticateEnfant();
        }
    }

    private void authenticateUser() {
        String email = emailField.getText().trim();
        String password = passwrdField.getText().trim();

        if (email.isEmpty() || password.isEmpty()) {
            showAlert("Erreur", "Veuillez remplir tous les champs", Alert.AlertType.ERROR);
            return;
        }

        try {
            User user = userService.authenticate(email, password);
            if (user != null) {
                UserSession.getInstance().startUserSession(user);
                redirectBasedOnRole(user.getRole());
            } else {
                showAlert("Erreur", "Email ou mot de passe incorrect", Alert.AlertType.ERROR);
            }
        } catch (Exception e) {
            showError("Erreur d'authentification", e.getMessage());
        }
    }

    private void authenticateEnfant() {
        String username = usernameField.getText().trim();
        String code = passwordField.getText().trim();

        if (username.isEmpty() || code.isEmpty()) {
            showAlert("Erreur", "Veuillez remplir tous les champs", Alert.AlertType.ERROR);
            return;
        }

        try {
            Enfant enfant = enfantService.authenticate(username, code);
            if (enfant != null) {
                UserSession.getInstance().startEnfantSession(enfant);
                checkVoiceEnrollmentStatus();
                redirectToEnfantPage(enfant);
            } else {
                showAlert("Erreur", "Nom d'utilisateur ou code incorrect", Alert.AlertType.ERROR);
            }
        } catch (Exception e) {
            showError("Erreur d'authentification", e.getMessage());
        }
    }

    private void handleVoiceEnrollment() {
        String username = usernameField.getText().trim();
        if (username.isEmpty()) {
            showAlert("Erreur", "Veuillez entrer votre username", Alert.AlertType.ERROR);
            return;
        }

        new Thread(() -> {
            try {
                Platform.runLater(() -> {
                    voiceStatusLabel.setText("Dites 'monsecret'...");
                    voiceStatusLabel.setStyle("-fx-text-fill: #2196F3;");
                });

                Enfant enfant = enfantService.findByUsername(username);
                if (enfant == null) {
                    throw new Exception("Enfant non trouvé");
                }

                byte[] voiceSample = microphoneCapture.captureAudio(3);
                String transcription = huggingFaceService.transcribeAudio(voiceSample);

                if (!transcription.equalsIgnoreCase("monsecret")) {
                    throw new Exception("Mot secret incorrect. Veuillez dire 'monsecret'.");
                }

                voiceAuthService.createVoiceProfile(enfant.getId(), voiceSample);

                Platform.runLater(() -> {
                    voiceStatusLabel.setText("✅ Enregistrement réussi");
                    voiceStatusLabel.setStyle("-fx-text-fill: #4CAF50;");
                    updateVoiceButtonsState(true);
                    showAlert("Succès", "Vous pouvez maintenant vous connecter par voix", Alert.AlertType.INFORMATION);
                });
            } catch (Exception e) {
                Platform.runLater(() -> {
                    voiceStatusLabel.setText("❌ Échec: " + e.getMessage());
                    voiceStatusLabel.setStyle("-fx-text-fill: #F44336;");
                    showError("Erreur d'enregistrement", e.getMessage());
                });
            }
        }).start();
    }

    private void handleVoiceLogin() {
        String username = usernameField.getText().trim();
        if (username.isEmpty()) {
            showAlert("Erreur", "Veuillez entrer votre username", Alert.AlertType.ERROR);
            return;
        }

        new Thread(() -> {
            try {
                Platform.runLater(() -> {
                    voiceStatusLabel.setText("Dites 'monsecret'...");
                    voiceStatusLabel.setStyle("-fx-text-fill: #2196F3;");
                });

                Enfant enfant = enfantService.findByUsername(username);
                if (enfant == null) {
                    throw new Exception("Enfant non trouvé");
                }

                byte[] currentVoice = microphoneCapture.captureAudio(3);
                boolean authenticated = voiceAuthService.verifyVoice(enfant.getId(), currentVoice, huggingFaceService);

                Platform.runLater(() -> {
                    if (authenticated) {
                        voiceStatusLabel.setText("✅ Connexion réussie");
                        voiceStatusLabel.setStyle("-fx-text-fill: #4CAF50;");
                        try {
                            UserSession.getInstance().startEnfantSession(enfant);
                            redirectToEnfantPage(enfant);
                        } catch (Exception e) {
                            showError("Erreur", e.getMessage());
                        }
                    } else {
                        voiceStatusLabel.setText("❌ Échec de connexion");
                        voiceStatusLabel.setStyle("-fx-text-fill: #F44336;");
                    }
                });
            } catch (Exception e) {
                Platform.runLater(() -> {
                    voiceStatusLabel.setText("⚠️ Erreur technique");
                    voiceStatusLabel.setStyle("-fx-text-fill: #FF9800;");
                    showError("Erreur d'authentification", e.getMessage());
                });
            }
        }).start();
    }

    private void redirectBasedOnRole(String role) throws IOException {
        String fxmlFile = switch (role.toLowerCase()) {
            case "parent" -> "/GesEnfParent.fxml";
            case "medecin" -> "/MedecinDashboard.fxml";
            case "admin" -> "/GesUsersAdmin.fxml";
            default -> throw new IOException("Rôle non reconnu: " + role);
        };
        loadFXMLFile(fxmlFile);
    }

    private void redirectToEnfantPage(Enfant enfant) throws IOException {
        loadFXMLFile("/signup.fxml"); // À remplacer par votre FXML de dashboard enfant
    }

    private void loadSignupPage() throws IOException {
        loadFXMLFile("/signup.fxml");
    }

    private void loadFXMLFile(String fxmlFile) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource(fxmlFile));
        Stage stage = (Stage) loginButton.getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }

    private void showAlert(String title, String message, Alert.AlertType type) {
        Platform.runLater(() -> {
            Alert alert = new Alert(type);
            alert.setTitle(title);
            alert.setHeaderText(null);
            alert.setContentText(message);
            alert.showAndWait();
        });
    }

    private void showError(String title, String message) {
        showAlert(title, message, Alert.AlertType.ERROR);
    }
}*/