package GesUsers.tests;

import GesUsers.services.HuggingFaceService;
import GesUsers.services.MicrophoneCapture;

public class HuggingFaceTester {
    public static void main(String[] args) {
        /*HuggingFaceService service = new HuggingFaceService();

        // Chemin relatif depuis les ressources
        String audioPath = HuggingFaceTester.class.getClassLoader()
                .getResource("test.wav")
                .getPath();

        // Pour Windows: remplacer les / par \ si nécessaire
        audioPath = audioPath.replaceFirst("/", "");

        try {
            System.out.println("Début de la transcription...");
            String result = service.transcribeAudio(audioPath);
            System.out.println("✅ Résultat : " + result);
        } catch (Exception e) {
            System.err.println("❌ Erreur : ");
            e.printStackTrace();
        }*/
        HuggingFaceService service = new HuggingFaceService();

        System.out.println("=== Système de Transcription Vocale ===");
        System.out.println("Appuyez sur Ctrl+C pour quitter");

        try {
            while (true) {
                try {
                    byte[] audioData = MicrophoneCapture.captureAudio(5); // 5 secondes
                    System.out.println("\n🔄 Traitement...");

                    String text = service.transcribeAudio(audioData);
                    System.out.println("✅ Résultat : " + text);

                    Thread.sleep(500); // Pause entre enregistrements
                } catch (Exception e) {
                    System.err.println("⚠️ Erreur temporaire : " + e.getMessage());
                }
            }
        } catch (Exception e) {
            System.err.println("❌ Erreur critique : " + e.getMessage());
        }
    }
}