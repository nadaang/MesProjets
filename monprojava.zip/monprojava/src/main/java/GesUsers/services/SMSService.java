package GesUsers.services;

import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;

public class SMSService {
    // Remplacez par vos identifiants Twilio
    public static final String ACCOUNT_SID = "AC60cf323c66a96578918395d52f1f4bf8";
    public static final String AUTH_TOKEN = "08ca2e60511c07cd554053a1c1364b3b";
    public static final String TWILIO_NUMBER = "+18573825265"; // Votre numéro Twilio

    static {
        Twilio.init(ACCOUNT_SID, AUTH_TOKEN);
    }

    public static String sendVerificationCode(String phoneNumber) {
        // Générer un code aléatoire (6 chiffres)
        String verificationCode = String.format("%06d", (int)(Math.random() * 1000000));

        String messageBody = "Votre code de vérification EduCare: " + verificationCode;

        try {
            Message message = Message.creator(
                    new PhoneNumber(phoneNumber),
                    new PhoneNumber(TWILIO_NUMBER),
                    messageBody
            ).create();

            return verificationCode;
        } catch (Exception e) {
            System.err.println("Erreur d'envoi SMS: " + e.getMessage());
            return null;
        }
    }



    public static String sendAnimalCaptcha(String phoneNumber, String username) {
        // Liste des animaux disponibles
        String[] animals = {"🐶 Chien", "🐱 Chat", "🐭 Souris", "🐹 Hamster",
                "🐰 Lapin", "🦊 Renard", "🐻 Ours", "🐼 Panda"};

        // Générer un animal basé sur le hash du username
        int hash = username.hashCode();
        String selectedAnimal = animals[Math.abs(hash % animals.length)];

        // Message explicatif
        String messageBody = "EduCare - Animal CAPTCHA pour " + username + ":\n"
                + "Pour se connecter, votre enfant devra toujours choisir: "
                + selectedAnimal + "\n"
                + "(Cet animal est lié à son pseudo)";

        try {
            Message.creator(
                    new PhoneNumber(phoneNumber),
                    new PhoneNumber(TWILIO_NUMBER),
                    messageBody
            ).create();

            return selectedAnimal.split(" ")[0]; // Retourne juste l'emoji
        } catch (Exception e) {
            System.err.println("Erreur d'envoi SMS: " + e.getMessage());
            return null;
        }
    }





}