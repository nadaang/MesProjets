package GesUsers.services;

import javax.sound.sampled.*;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;

public class MicrophoneCapture {
    public static byte[] captureAudio(int durationSec) throws Exception {
        // Configuration audio optimisée pour Whisper
        AudioFormat format = new AudioFormat(
                16000,  // Sample rate (16kHz)
                16,     // Sample size in bits
                1,      // Channels (mono)
                true,   // Signed
                false   // Little endian
        );

        DataLine.Info info = new DataLine.Info(TargetDataLine.class, format);
        if (!AudioSystem.isLineSupported(info)) {
            throw new Exception("Microphone non supporté avec ce format");
        }

        TargetDataLine microphone = (TargetDataLine) AudioSystem.getLine(info);
        microphone.open(format);
        microphone.start();

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buffer = new byte[1024];
        int bytesRead;

        System.out.println("🎤 Enregistrement (Parlez maintenant)...");
        long endTime = System.currentTimeMillis() + (durationSec * 1000);

        while (System.currentTimeMillis() < endTime) {
            bytesRead = microphone.read(buffer, 0, buffer.length);
            out.write(buffer, 0, bytesRead);
        }

        microphone.close();

        // Conversion en WAV
        ByteArrayOutputStream wavOut = new ByteArrayOutputStream();
        AudioSystem.write(
                new AudioInputStream(
                        new ByteArrayInputStream(out.toByteArray()),
                        format,
                        out.size()
                ),
                AudioFileFormat.Type.WAVE,
                wavOut
        );

        return wavOut.toByteArray();
    }
}