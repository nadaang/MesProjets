/*package GesUsers.services;

import GesUsers.entities.VoiceItChildProfile;
import java.util.HashMap;
import java.util.Map;

public class VoiceAuthManager {
    private static final Map<String, VoiceItChildProfile> voiceProfiles = new HashMap<>();

    public static void enroll(String username, byte[] voiceSample, String secretWord) {
        // Créer un nouveau profil avec le mot secret choisi
        VoiceItChildProfile profile = new VoiceItChildProfile();
        profile.setVoiceitId("voice_" + username);
        profile.setSecretWord(secretWord);
        profile.setEnrollmentStatus("COMPLETED");

        voiceProfiles.put(username, profile);
    }

    public static boolean verify(String username, byte[] currentVoice, HuggingFaceService hfService) throws Exception {
        VoiceItChildProfile profile = voiceProfiles.get(username);
        if (profile == null) return false;

        String transcription = hfService.transcribeAudio(currentVoice);
        return transcription.equalsIgnoreCase(profile.getSecretWord());
    }

    public static VoiceItChildProfile getProfile(String username) {
        return voiceProfiles.get(username);
    }
}*/