/*package GesUsers.services;

import GesUsers.entities.VoiceItChildProfile;
import java.util.HashMap;
import java.util.Map;

public class VoiceAuthService {
    // In a real application, this would connect to a database
    private static final Map<Integer, VoiceItChildProfile> voiceProfiles = new HashMap<>();
    private static final String SECRET_WORD = "monsecret";

    public VoiceItChildProfile findByChildId(int childId) {
        return voiceProfiles.get(childId);
    }

    public void createVoiceProfile(int childId, byte[] voiceSample) {
        VoiceItChildProfile profile = new VoiceItChildProfile(childId, "voice_" + childId);
        profile.setEnrollmentStatus("COMPLETED");
        voiceProfiles.put(childId, profile);
    }

    public boolean verifyVoice(int childId, byte[] currentVoice, HuggingFaceService hfService) throws Exception {
        VoiceItChildProfile profile = voiceProfiles.get(childId);
        if (profile == null || !"COMPLETED".equals(profile.getEnrollmentStatus())) {
            return false;
        }

        String transcription = hfService.transcribeAudio(currentVoice);
        return transcription.equalsIgnoreCase(SECRET_WORD);
    }
}*/