package GesUsers.services;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import java.util.Base64;

public class HuggingFaceService {
    private static final String HF_API_KEY = "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";
    private static final String HF_API_URL = "https://api-inference.huggingface.co/models/openai/whisper-small";

    public String transcribeAudio(byte[] audioBytes) throws Exception {
        try {
            // Vérification des données
            if (audioBytes == null || audioBytes.length < 1024) {
                throw new Exception("Audio trop court ou vide");
            }

            String audioBase64 = Base64.getEncoder().encodeToString(audioBytes);

            CloseableHttpClient client = HttpClients.createDefault();
            HttpPost post = new HttpPost(HF_API_URL);
            post.setHeader("Authorization", "Bearer " + HF_API_KEY);
            post.setHeader("Content-Type", "application/json");
            post.setHeader("x-wait-for-model", "true");

            JsonObject requestBody = new JsonObject();
            requestBody.addProperty("inputs", audioBase64);
            post.setEntity(new StringEntity(requestBody.toString()));

            String response = EntityUtils.toString(client.execute(post).getEntity());
            JsonObject jsonResponse = JsonParser.parseString(response).getAsJsonObject();

            if (jsonResponse.has("error")) {
                throw new Exception("API error: " + jsonResponse.get("error").getAsString());
            }

            return jsonResponse.get("text").getAsString();
        } catch (Exception e) {
            throw new Exception("Transcription failed: " + e.getMessage());
        }
    }
}