package GesUsers.services;

import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

public class CaptchaService {
    // Utilisez votre NOUVELLE clé secrète ici
    private static final String SECRET_KEY = "6LefACIrAAAAAK1hL-WRhGHaEyrvatXY6m6t14ze";
    private static final String VERIFY_URL = "https://www.google.com/recaptcha/api/siteverify";

    public boolean verify(String captchaResponse, String clientIp) throws Exception {
        if (captchaResponse == null || captchaResponse.isEmpty()) {
            throw new IllegalArgumentException("Token reCAPTCHA vide");
        }

        String params = "secret=" + SECRET_KEY +
                "&response=" + captchaResponse +
                "&remoteip=" + clientIp;

        HttpPost post = new HttpPost(VERIFY_URL + "?" + params);

        try (CloseableHttpClient httpClient = HttpClients.createDefault()) {
            String response = EntityUtils.toString(httpClient.execute(post).getEntity());
            JsonNode json = new ObjectMapper().readTree(response);
            return json.get("success").asBoolean();
        }
    }
}