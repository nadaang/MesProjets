<?php

namespace App\Controller;

use App\Entity\Enfant;
use App\Entity\AppEnf;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;


use App\Entity\User;
use App\Entity\AppUser;

use App\Form\UserType;
use Doctrine\ORM\EntityManagerInterface;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\HandleRequest;

use Symfony\Component\Form\Extension\Core\Type\TextType;


use App\Form\EnfantType;
use Symfony\Bundle\SecurityBundle\Security;


use Symfony\Component\Security\Http\Authentication\AuthenticationUtils;

use App\Form\LoginType;
use Symfony\Component\Form\FormFactoryInterface;



use Symfony\Component\Validator\Validator\ValidatorInterface;

final class ShowController extends AbstractController
{
    


    #[Route('/show', name: 'show')]
    public function show(): Response
    {
        return $this->render('back.html.twig', [
            'controller_name' => 'ShowController',
        ]);
    }



    #[Route('/showdashboard', name: 'showdashboard')]
    public function showdashboard(): Response
    {
        return $this->render('dashboard.html.twig', [
            'controller_name' => 'ShowController',
        ]);
    }



    

/*
    #[Route('/showenfants', name: 'showenfants')]
    public function showenfants(): Response
    {
        return $this->render('show_enfants.html.twig', [
            'controller_name' => 'ShowController',
        ]);
    }
*/



    #[Route('/showdashboardP', name: 'showdashboardP')]
    public function showdashboardP(): Response
    {
        return $this->render('dashboarddparent.html.twig', [
            'controller_name' => 'ShowController',
        ]);
    }

/*   
    #[Route('/showgesusers', name: 'showgesusers')]
    public function showgesusers(): Response
    {
        return $this->render('gesusers.html.twig', [
            'controller_name' => 'ShowController',
        ]);
    }
*/


#[Route('/showgesusers', name: 'showgesusers')]
    public function showgesusers(ManagerRegistry $doctrine): Response
    {

        $repository = $doctrine->getRepository(User::class);
        $users = $repository->findAll();

        $hasChildren = false;

        foreach ($users as $user) {
            if ($user->getRole() === 'enfant') {
                $hasChildren = true;
                break;
            }
        }


        return $this->render('gesusers.html.twig', [
            'controller_name' => 'ShowController',
            'users' => $users,
            'hasChildren'=> $hasChildren

            
        ]);
    }







    #[Route('/showprofileuser', name: 'showprofileuser')]
    public function showprofileuser(): Response
    {
        return $this->render('profileUser.html.twig', [
            'controller_name' => 'ShowController',
        ]);
    }


/*
    #[Route('/showprofileparent', name: 'showprofileparent')]
    public function showprofileparent(): Response
    {
        return $this->render('profileparent.html.twig', [
            'controller_name' => 'ShowController',
        ]);
    }
*/




#[Route('/showprofileparent', name: 'showprofileparent')]
public function showprofileparent(ManagerRegistry $doctrine): Response
{
    // Récupérer l'utilisateur actuellement connecté (AppUser)
    $appuser = $this->getUser();

    // Vérifier si l'utilisateur est bien un AppUser
    if (!$appuser instanceof AppUser) {
        throw $this->createAccessDeniedException('Vous devez être connecté pour accéder à cette page.');
    }

    // Récupérer l'entité "User" associée à l'AppUser via la méthode getUser()
    $user = $appuser->getUser();

    // Vérifier si l'entité User associée existe
    if (!$user) {
        throw $this->createNotFoundException('Utilisateur associé introuvable.');
    }

    // Passer l'AppUser et l'entité User à la vue
    return $this->render('profileparent.html.twig', [
        'appUser' => $appuser,   // Passer l'AppUser connecté
        'user' => $user          // Passer l'entité User spécifique associée à AppUser
    ]);
}











/*
    #[Route('/showsignup2', name: 'showsignup2')]
    public function showsignup2(): Response
    {
        return $this->render('signup2.html.twig', [
            'controller_name' => 'ShowController',
        ]);
    }
*/



    #[Route('/showsignup', name: 'showsignup')]
    public function showsignup(): Response
    {
        return $this->render('signup.html.twig', [
            'controller_name' => 'ShowController',
        ]);
    }

    #[Route('/showtest', name: 'showtest')]
    public function showtest(): Response
    {
        return $this->render('test.html.twig', [
            'controller_name' => 'ShowController',
        ]);
    }


/*
    #[Route('/showuser', name: 'showuser')]
    public function showuser(): Response
    {
        return $this->render('user.html.twig', [
            'controller_name' => 'ShowController',
        ]);
    }
*/
/*fctnnl
#[Route('/showuser/{id?0}', name: 'showuser')]
    public function showuser(User $user=null, ManagerRegistry $doctrine, Request $request ): Response
    {
        if(!$user){
            $user = new User();
        }

        
        $form = $this->createForm(UserType::class, $user);

        
        $form->handleRequest($request);
        if($form->isSubmitted()){
            $manager = $doctrine->getManager();
            $manager->persist($user);
            $manager->flush();

            // Ajout d'un message flash
            $this->addFlash('success', $user->getNom() . " a été ajouté avec succès !");

            // Redirection vers la page signup après ajout
            return $this->redirectToRoute('showgesusers');

        } 


        return $this->render('user.html.twig', [
            'controller_name' => 'ShowController',
            'form' => $form->createView(),
            'user' => $user
        ]);
    }
*/



#[Route('/showuser/{id}', name: 'showuser')]
public function showUser(ManagerRegistry $doctrine, Request $request, int $id): Response
{
    // Récupération de l'utilisateur par son ID
    $user = $doctrine->getRepository(User::class)->find($id);
    if (!$user) {
        throw $this->createNotFoundException('Utilisateur non trouvé');
    }

    // Création du formulaire basé sur l'utilisateur existant
    $form = $this->createForm(UserType::class, $user, [
        'role' => $user->getRole(),
    ]);

    // Supprimer le champ 'mdp'
    $form->remove('mdp');


    // Supprimer le btn 'ajouter'
    $form->remove('Ajouter');

    // Ajouter dynamiquement le champ 'resultatquiz'
    if ($user->getRole() === 'enfant') {
    $form->add('resultatquiz', TextType::class, [
        'label' => 'Résultat Quiz',
        'required' => false,
    ]);
    }



    // Rendre le champ 'role' visible et en lecture seule
    $form->add('role', TextType::class, [
        'label' => 'Rôle',
        'data' => $user->getRole(),
        'attr' => ['readonly' => true], // Empêcher la modification
    ]);

    // Gestion de la soumission du formulaire
    $form->handleRequest($request);
    if ($form->isSubmitted() && $form->isValid()) {
        // Mise à jour de l'utilisateur dans la base de données
        $manager = $doctrine->getManager();
        $manager->persist($user);
        $manager->flush();

        // Message flash de succès
        $this->addFlash('success', 'Profil mis à jour avec succès !');

        // Redirection après la mise à jour
        //return $this->redirectToRoute('showuser', ['id' => $user->getId()]);
        return $this->redirectToRoute('showgesusers');

    }

    return $this->render('user.html.twig', [
        'form' => $form->createView(),
        'user' => $user,
    ]);
}







/*
    #[Route('/showuserenf', name: 'showuserenf')]
    public function showuserenf(): Response
    {
        return $this->render('userenf.html.twig', [
            'controller_name' => 'ShowController',
        ]);
    }


    #[Route('/showdetailsenf', name: 'showdetails')]
    public function showdetailsenf(): Response
    {
        return $this->render('detailsEnf.html.twig', [
            'controller_name' => 'ShowController',
        ]);
    }
*/


#[Route('/modifier/{id}', name: 'showuserenf')]
public function showuserenf(int $id, EntityManagerInterface $entityManager): Response
{
    // Récupérer l'enfant par son ID
    $enfant = $entityManager->getRepository(Enfant::class)->find($id);

    if (!$enfant) {
        throw $this->createNotFoundException('Enfant non trouvé');
    }

    // Retourner la vue avec les données de l'enfant
    return $this->render('userenf.html.twig', [
        'enfant' => $enfant,
    ]);
}












    #[Route('/showsignup2/{type}', name: 'showsignup2')]
    public function showsignup2(ManagerRegistry $doctrine, Request $request, string $type = 'parent', ValidatorInterface $validator): Response
    {
        $user = new User(); // Remplace par ton entité utilisateur
        $form = $this->createForm(UserType::class, $user, [
            'role' => $type,  // Pass the role here
        ]);


        $form->handleRequest($request);
        if($form->isSubmitted() && $form->isValid()){
            $manager = $doctrine->getManager();
            $manager->persist($user);
            $manager->flush();

            // Ajout d'un message flash
            $this->addFlash('success', $user->getNom() . " a été ajouté avec succès !");

            // Redirection vers la page signup après ajout
            //return $this->redirectToRoute('showsignup');
            return $this->redirectToRoute('app_login');

        

        } else {
            // 🔥 Debug : voir les erreurs
            dump($form->getErrors(true));
        }
    
        return $this->render('signup2.html.twig', [
            'controller_name' => 'ShowController',
            'role' => $type,
            'form' => $form->createView(), // Passe le formulaire à la vue
        ]);

    }



    #[Route('/showajoutenf', name: 'showajoutenf')]
    public function showajoutenf(Request $request, EntityManagerInterface $entityManager, Security $security, ValidatorInterface $validator): Response
    {
        $enfant = new Enfant(); // Remplace par ton entité utilisateur
        $form = $this->createForm(EnfantType::class, $enfant);

    
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            // Récupérer l'utilisateur connecté
            //$user = $security->getUser();
            
            $appuser = $this->getUser(); 

            if($appuser instanceof AppUser){ 
                //L'ajout de la vérification instanceof AppUser te permet de t'assurer que tu travailles bien avec un objet AppUser
                $user = $appuser->getUser();
            

            if ($appuser) {
                $user = $appuser->getUser();
                $enfant->setParent($user); // Affecter le parent automatiquement
                $enfant->setCode(uniqid()); // Générer un code unique
                $enfant->setResquiz(null); // Initialiser resquiz

                // Sauvegarde en base de données
                $entityManager->persist($enfant);
                $entityManager->flush();

                // Créer un AppEnf associé
                $appEnf = new AppEnf();
                $appEnf->setUsername($enfant->getUsername()); // Utilise le username de l'enfant
                $appEnf->setCode('123'); // Utilise le code de l'enfant
                $appEnf->setEnf($enfant); // Lie l'AppEnf à l'Enfant

                // Sauvegarde de l'AppEnf
                $entityManager->persist($appEnf);
                $entityManager->flush();




                return $this->redirectToRoute('showenfants'); // Redirection après ajout
            }} else {
                $this->addFlash('error', 'Aucun utilisateur connecté.');
            }
        } else {
            // 🔥 Debug : voir les erreurs
            dump($form->getErrors(true));
        }

        return $this->render('ajoutenf.html.twig', [
            'controller_name' => 'ShowController',
            'form' => $form->createView(), // Passe le formulaire à la vue
        ]);
    }














    #[Route('/delete/{id}', name: 'deleteuser')]
    public function deleteUser(int $id, EntityManagerInterface $entityManager): Response
    {
        $user = $entityManager->getRepository(User::class)->find($id);
    
        if (!$user) {
            throw $this->createNotFoundException('Utilisateur non trouvé');
        }
    
        $entityManager->remove($user);
        $entityManager->flush();
    
        $this->addFlash('success', 'Utilisateur supprimé avec succès.');
    
        return $this->redirectToRoute('showgesusers'); 
    }
    

    #[Route('/deletee/{id}', name: 'deleteenfant')]
    public function deleteenf(int $id, EntityManagerInterface $entityManager): Response
    {
        $enf = $entityManager->getRepository(Enfant::class)->find($id);
    
        if (!$enf) {
            throw $this->createNotFoundException('enfant non trouvé');
        }
    
        $entityManager->remove($enf);
        $entityManager->flush();
    
        $this->addFlash('success', 'enfant supprimé avec succès.');
    
        return $this->redirectToRoute('showenfants'); 
    }
    



 /*   #[Route('/login', name: 'app_login')]
public function login(AuthenticationUtils $authenticationUtils, FormFactoryInterface $formFactory, Request $request): Response
{
    $form = $formFactory->create(LoginType::class);

    // Récupérer l'erreur d'authentification si présente
    $error = $authenticationUtils->getLastAuthenticationError();

    // Récupérer le dernier email entré
    $lastUsername = $authenticationUtils->getLastUsername();

    return $this->render('login.html.twig', [
        'form' => $form->createView(),
        'error' => $error,
        'last_username' => $lastUsername 
    ]);
}*/

    


#[Route('/showenfants', name: 'showenfants')]
public function showEnfants(ManagerRegistry $doctrine, Security $security): Response
{
    // Récupérer l'utilisateur connecté (le parent)
    $appuser = $this->getUser();
    
    if (!$appuser instanceof AppUser) {
        throw $this->createAccessDeniedException('Accès refusé.');
    }

    // Récupérer l'utilisateur principal associé à l'AppUser
    $user = $appuser->getUser();
    
    if (!$user) {
        throw $this->createNotFoundException('Utilisateur non trouvé.');
    }

    // Récupérer les enfants associés au parent (l'utilisateur)
    $enfants = $doctrine->getRepository(Enfant::class)->findBy(['parent' => $user]);

    return $this->render('show_enfants.html.twig', [
        'controller_name' => 'ShowController',
        'enfants' => $enfants,  // Passer les enfants à la vue
    ]);
}



#[Route('/update/{id}', name: 'updateenf', methods: ['POST'])]
public function updateEnf(int $id, Request $request, EntityManagerInterface $entityManager): Response
{
    $enfant = $entityManager->getRepository(Enfant::class)->find($id);

    if (!$enfant) {
        throw $this->createNotFoundException('Enfant non trouvé');
    }

    // Mettre à jour les informations de l'enfant
    $enfant->setUsername($request->get('username'));
    $enfant->setCode($request->get('code'));
    $enfant->setType($request->get('typeenf'));
    // Si un nouveau mot de passe est fourni, vous pouvez l'ajouter ici

    $entityManager->flush();

    $this->addFlash('success', 'Enfant mis à jour avec succès.');

    return $this->redirectToRoute('showenfants'); // Redirigez vers la page de la liste des enfants
}



#[Route('/showdetails/{id}', name: 'showdetails')]
public function showdetails($id, ManagerRegistry $doctrine): Response
{
    // Récupérer l'utilisateur par son ID
    $repository = $doctrine->getRepository(Enfant::class);
    $enfant = $repository->find($id);

    // Si l'utilisateur n'est pas trouvé, retourner une page d'erreur (404 par exemple)
    if (!$enfant) {
        throw $this->createNotFoundException('L\'utilisateur n\'existe pas');
    }

    // Passer les données à la vue
    return $this->render('detailsEnf.html.twig', [
        'enfant' => $enfant
    ]);
}



}
