<?php

namespace App\EventListener;

use App\Entity\User;
use App\Entity\AppUser;
use Doctrine\Persistence\Event\LifecycleEventArgs;
use Symfony\Component\PasswordHasher\Hasher\UserPasswordHasherInterface;

class UserCreationListener
{
    private UserPasswordHasherInterface $passwordHasher;

    public function __construct(UserPasswordHasherInterface $passwordHasher)
    {
        $this->passwordHasher = $passwordHasher;
    }

    public function postPersist(LifecycleEventArgs $event): void
    {
        $entity = $event->getObject(); // Récupère l'entité qui vient d'être persistée

        // Vérifie si l'entité est bien un User
        if (!$entity instanceof User) {
            return;
        }

        $entityManager = $event->getObjectManager();

        // Création d'un AppUser lié à User
        $appUser = new AppUser();
        $appUser->setEmail($entity->getEmail());
        $appUser->setPassword($this->passwordHasher->hashPassword($appUser, $entity->getMdp()));
        $appUser->setRoles([$entity->getRole()]);

        $appUser->setUser($entity);

        // Persiste et flush l'AppUser
        $entityManager->persist($appUser);
        $entityManager->flush();
    }
}
