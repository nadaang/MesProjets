<?php

namespace App\Entity;

use App\Repository\EnfantRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

use Symfony\Component\Validator\Constraints as Assert;

#[ORM\Entity(repositoryClass: EnfantRepository::class)]
class Enfant
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 255)]
    #[Assert\NotBlank(message: "Donner un username à votre enfant !")]
    private ?string $username = null;

    #[ORM\ManyToOne(inversedBy: 'enfants')]
    #[ORM\JoinColumn(nullable: false)]
    private ?User $parent = null;

    #[ORM\Column(length: 255)]
    private ?string $code = null;

    #[ORM\Column(length: 255)]
    private ?string $type = null;

    #[ORM\Column(nullable: true)]
    private ?int $resquiz = null;

    /**
     * @var Collection<int, AppEnf>
     */
    #[ORM\OneToMany(targetEntity: AppEnf::class, mappedBy: 'enf', orphanRemoval: true)]
    private Collection $appEnfs;

    public function __construct()
    {
        $this->appEnfs = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getUsername(): ?string
    {
        return $this->username;
    }

    public function setUsername(string $username): static
    {
        $this->username = $username;

        return $this;
    }

    public function getParent(): ?User
    {
        return $this->parent;
    }

    public function setParent(?User $parent): static
    {
        $this->parent = $parent;

        return $this;
    }

    public function getCode(): ?string
    {
        return $this->code;
    }

    public function setCode(string $code): static
    {
        $this->code = $code;

        return $this;
    }

    public function getType(): ?string
    {
        return $this->type;
    }

    public function setType(string $type): static
    {
        $this->type = $type;

        return $this;
    }

    public function getResquiz(): ?int
    {
        return $this->resquiz;
    }

    public function setResquiz(?int $resquiz): static
    {
        $this->resquiz = $resquiz;

        return $this;
    }

    /**
     * @return Collection<int, AppEnf>
     */
    public function getAppEnfs(): Collection
    {
        return $this->appEnfs;
    }

    public function addAppEnf(AppEnf $appEnf): static
    {
        if (!$this->appEnfs->contains($appEnf)) {
            $this->appEnfs->add($appEnf);
            $appEnf->setEnf($this);
        }

        return $this;
    }

    public function removeAppEnf(AppEnf $appEnf): static
    {
        if ($this->appEnfs->removeElement($appEnf)) {
            // set the owning side to null (unless already changed)
            if ($appEnf->getEnf() === $this) {
                $appEnf->setEnf(null);
            }
        }

        return $this;
    }
}
