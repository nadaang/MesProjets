<?php

namespace App\Entity;

use App\Repository\AppEnfRepository;
use Doctrine\ORM\Mapping as ORM;




#[ORM\Entity(repositoryClass: AppEnfRepository::class)]
class AppEnf 
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 255)]
    private ?string $username = null;

    #[ORM\Column(length: 255)]
    private ?string $code = null;

    #[ORM\ManyToOne(inversedBy: 'appEnfs')]
    #[ORM\JoinColumn(nullable: false)]
    private ?Enfant $enf = null;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getUsername(): ?string
    {
        return $this->username;
    }

    public function setUsername(string $username): static
    {
        $this->username = $username;

        return $this;
    }

    public function getCode(): ?string
    {
        return $this->code;
    }

    public function setCode(string $code): static
    {
        $this->code = $code;

        return $this;
    }

    public function getEnf(): ?Enfant
    {
        return $this->enf;
    }

    public function setEnf(?Enfant $enf): static
    {
        $this->enf = $enf;

        return $this;
    }

    


}


