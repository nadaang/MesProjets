<?php
/*// src/Security/EnfAuthenticator.php
namespace App\Security;

use App\Entity\AppEnf;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Generator\UrlGeneratorInterface;
use Symfony\Component\Security\Core\Authentication\Token\TokenInterface;
use Symfony\Component\Security\Core\Exception\CustomUserMessageAuthenticationException;
use Symfony\Component\Security\Http\Authenticator\AbstractLoginFormAuthenticator;
use Symfony\Component\Security\Http\Authenticator\Passport\Badge\CsrfTokenBadge;
use Symfony\Component\Security\Http\Authenticator\Passport\Badge\UserBadge;
use Symfony\Component\Security\Http\Authenticator\Passport\Credentials\CustomCredentials;
use Symfony\Component\Security\Http\Authenticator\Passport\Passport;
use Symfony\Component\Security\Http\Util\TargetPathTrait;

class EnfAuthenticator extends AbstractLoginFormAuthenticator
{
    use TargetPathTrait;

    public const LOGIN_ROUTE = 'app_login'; // Utilise la même route que LoginAuthAuthenticator

    public function __construct(
        private UrlGeneratorInterface $urlGenerator,
        private EntityManagerInterface $entityManager
    ) {
    }

    public function supports(Request $request): bool
    {
        // Vérifie si la requête est pour la route de connexion et si elle contient un username
        return $request->getPathInfo() === '/login' 
            && $request->isMethod('POST') 
            && $request->request->has('username'); // Vérifie si le formulaire enfant est soumis
    }

    public function authenticate(Request $request): Passport
{
    $username = $request->request->get('username');
    $code = $request->request->get('code');

    // Debug : affiche les valeurs
    dump('Username:', $username, 'Code:', $code);

    // Recherche l'AppEnf correspondant
    $appEnf = $this->entityManager->getRepository(AppEnf::class)->findOneBy(['username' => $username]);

    // Debug : affiche l'AppEnf trouvé
    dump('AppEnf trouvé:', $appEnf);

    if (!$appEnf) {
        throw new CustomUserMessageAuthenticationException('Username not found.');
    }

    return new Passport(
        new UserBadge($username, function ($username) use ($appEnf) {
            return $appEnf;
        }),
        new CustomCredentials(function ($code, AppEnf $appEnf) {
            return $appEnf->getCode() === $code; // Vérifie si le code correspond
        }, $code),
        [
            new CsrfTokenBadge('authenticate', $request->request->get('_csrf_token')),
        ]
    );
}

    public function onAuthenticationSuccess(Request $request, TokenInterface $token, string $firewallName): ?Response
    {
        if ($targetPath = $this->getTargetPath($request->getSession(), $firewallName)) {
            return new RedirectResponse($targetPath);
        }

        // Redirige vers le tableau de bord des enfants après connexion
        return new RedirectResponse($this->urlGenerator->generate('showgesusers'));
    }

    protected function getLoginUrl(Request $request): string
    {
        return $this->urlGenerator->generate(self::LOGIN_ROUTE);
    }
}*/