<?php
// src/Security/LoginAuthAuthenticator.php
namespace App\Security;

use App\Entity\AppEnf;
use App\Entity\AppUser;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Generator\UrlGeneratorInterface;
use Symfony\Component\Security\Core\Authentication\Token\TokenInterface;
use Symfony\Component\Security\Core\Exception\CustomUserMessageAuthenticationException;
use Symfony\Component\Security\Http\Authenticator\AbstractLoginFormAuthenticator;
use Symfony\Component\Security\Http\Authenticator\Passport\Badge\CsrfTokenBadge;
use Symfony\Component\Security\Http\Authenticator\Passport\Badge\UserBadge;
use Symfony\Component\Security\Http\Authenticator\Passport\Credentials\PasswordCredentials;
use Symfony\Component\Security\Http\Authenticator\Passport\Passport;
use Symfony\Component\Security\Http\Util\TargetPathTrait;

class LoginAuthAuthenticator extends AbstractLoginFormAuthenticator
{
    use TargetPathTrait;

    public const LOGIN_ROUTE = 'app_login';

    private $entityManager;
    private $urlGenerator;

    public function __construct(EntityManagerInterface $entityManager, UrlGeneratorInterface $urlGenerator)
    {
        $this->entityManager = $entityManager;
        $this->urlGenerator = $urlGenerator;
    }

    public function supports(Request $request): bool
    {
        // Vérifie si la requête est pour la route de connexion et si elle est de type POST
        return $request->getPathInfo() === '/login' && $request->isMethod('POST');
    }

    public function authenticate(Request $request): Passport
    {
        // Vérifie si c'est une connexion parent ou enfant
        if ($request->request->has('email')) {
            // Connexion parent
            $email = $request->request->get('email');
            $password = $request->request->get('password');

            // Recherche l'utilisateur parent
            $appUser = $this->entityManager->getRepository(AppUser::class)->findOneBy(['email' => $email]);

            if (!$appUser) {
                throw new CustomUserMessageAuthenticationException('Email not found.');
            }

            return new Passport(
                new UserBadge($email, function ($email) use ($appUser) {
                    return $appUser;
                }),
                new PasswordCredentials($password),
                [
                    new CsrfTokenBadge('authenticate', $request->request->get('_csrf_token')),
                ]
            );
        } else {
            // Connexion enfant
            $username = $request->request->get('username');
            $code = $request->request->get('code');
            $enf= 
            // Recherche l'enfant
            $appEnf = $this->entityManager->getRepository(AppEnf::class)->findOneBy(['username' => $username]);

            if (!$appEnf || $appEnf->getCode() !== $code) {
                throw new CustomUserMessageAuthenticationException('Username or code is incorrect.');
            }

            return new Passport(
                new UserBadge($username, function ($username) use ($appEnf) {
                    return $appEnf;
                }),
                new PasswordCredentials($code), // Utilise le code comme "mot de passe"
                [
                    new CsrfTokenBadge('authenticate', $request->request->get('_csrf_token')),
                ]
            );
        }
    }

    public function onAuthenticationSuccess(Request $request, TokenInterface $token, string $firewallName): ?Response
    {
        if ($targetPath = $this->getTargetPath($request->getSession(), $firewallName)) {
            return new RedirectResponse($targetPath);
        }

        // Redirige en fonction du rôle de l'utilisateur
        $user = $token->getUser();
        $roles = $user->getRoles();

        if (in_array('admin', $roles)) {
            return new RedirectResponse($this->urlGenerator->generate('showdashboard'));
        }
        if (in_array('parent', $roles)) {
            return new RedirectResponse($this->urlGenerator->generate('showdashboardP'));
        }
        if (in_array('enfant', $roles)) {
            return new RedirectResponse($this->urlGenerator->generate('showgesusers'));
        }

        if (in_array('medecin', $roles)) {
            return new RedirectResponse($this->urlGenerator->generate('showgesusers'));
        }

        // Redirection par défaut
        return new RedirectResponse($this->urlGenerator->generate('homepage'));
    }

    protected function getLoginUrl(Request $request): string
    {
        return $this->urlGenerator->generate(self::LOGIN_ROUTE);
    }
}