<?php

namespace App\DataFixtures;

use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Persistence\ObjectManager;
use App\Entity\User;
use Doctrine\Bundle\FixturesBundle\FixtureGroupInterface;

#use Symfony\Component\PasswordHasher\Hasher\UserPasswordHasherInterface;

class UserFixture extends Fixture implements FixtureGroupInterface
{

/*
    private UserPasswordHasherInterface $passwordHasher;

    public function __construct(UserPasswordHasherInterface $passwordHasher)
    {
        $this->passwordHasher = $passwordHasher;
    }

*/

    public function load(ObjectManager $manager): void
    {
        // $product = new Product();
        // $manager->persist($product);

        $admin1 = new User();
        $admin1->setNom("admin1");
        $admin1->setPrenom("admin1");
        $admin1->setEmail("admin1@example.com");
        $admin1->setMdp("admin1"); //g pas fait le hashage ici comme ds la vidéo car je lai fait qqpart qd g crée appuser et g fait le lien entre elle et user
       // c déjà fait ds leventlistener
        // $appUser->setPassword($this->passwordHasher->hashPassword($appUser, "adminpassword")); // Hash du mot de passe

        $admin1->setRole("admin");
        $admin1->setNumTel("0123456789");
        $admin1->setDateNaissance(new \DateTime("2000-01-01"));
        
        $manager->persist($admin1);



        $medecin = new User();
        $medecin->setNom("medecin");
        $medecin->setPrenom("medecin");
        $medecin->setEmail("medecin@example.com");
        $medecin->setMdp("medecin");
        $medecin->setRole("medecin");
        $medecin->setNumTel("123");
        $medecin->setDateNaissance(new \DateTime("1990-01-01"));
        
        $manager->persist($medecin);
        

        $manager->flush();

    }

    public static function getGroups(): array
    {
        return ['users'];        
    }
    
}
