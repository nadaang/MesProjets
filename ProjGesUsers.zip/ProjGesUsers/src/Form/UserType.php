<?php

// src/Form/UserType.php
namespace App\Form;

use App\Entity\User;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
use Symfony\Component\Form\Extension\Core\Type\PasswordType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;


class UserType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        $builder
            ->add('nom', TextType::class, [
                'label' => 'Nom',
                
            ])
            ->add('prenom', TextType::class, [
                'label' => 'Prénom',
            ])
            ->add('email', EmailType::class, [
                'label' => 'Email',
                
            ])
            ->add('mdp', PasswordType::class, [
                'label' => 'Mot de passe',
                
            ])
            

           /* ->add('role', TextType::class, [
                'label' => 'Rôle',
                'data' => $options['role'], // Remplir avec la valeur du rôle passé au formulaire
                'attr' => ['readonly' => true], // Rendre le champ en lecture seule
            ])*/


            ->add('role', HiddenType::class, [
                'data' => $options['role'], // Remplir avec la valeur du rôle à définir
            ])
 

            
            ->add('numtel', TextType::class, [
                'label' => 'Numéro de téléphone',
                'required' => false,
                
            ])
            ->add('datenaissance', DateType::class, [
                'label' => 'Date de naissance',
                'widget' => 'single_text',
                'required' => false,
            ])

            // Ajouter le bouton de soumission
            ->add('Ajouter', SubmitType::class, [
                'label' => 'Ajouter', // Texte du bouton
                'attr' => ['class' => 'btn btn-primary'], // Classes CSS
            ]);



        // Ajouter le champ "typeenfant" uniquement si le rôle est "enfant"
        if ($options['role'] === 'enfant') {
            $builder->add('typeenfant', ChoiceType::class, [
                'label' => 'Type d\'enfant',
                'choices' => [
                    'Normal' => 'normal',
                    'Sourd' => 'sourd',
                    'Dyslexique' => 'dyslexique',
                ],
                'placeholder' => 'Choisissez un type',
                'required' => false,
            ]);
        }


        


    }

    public function configureOptions(OptionsResolver $resolver): void
    {
    $resolver->setDefaults([
        'data_class' => User::class,
        'role' => null, // Option pour passer le rôle depuis le contrôleur
    ]);

    $resolver->setAllowedTypes('role', ['null', 'string']);
    }

}
