<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20250219181754 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE TABLE app_enf (id INT AUTO_INCREMENT NOT NULL, enf_id INT NOT NULL, username VARCHAR(255) NOT NULL, code VARCHAR(255) NOT NULL, INDEX IDX_C080E15A48B4429B (enf_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('ALTER TABLE app_enf ADD CONSTRAINT FK_C080E15A48B4429B FOREIGN KEY (enf_id) REFERENCES enfant (id)');
    }

    public function down(Schema $schema): void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE app_enf DROP FOREIGN KEY FK_C080E15A48B4429B');
        $this->addSql('DROP TABLE app_enf');
    }
}
